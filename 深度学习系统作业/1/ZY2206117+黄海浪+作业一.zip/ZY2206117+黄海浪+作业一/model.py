import numpy as np


# neural network class
class neuralNetwork:

    # initialize the neural network
    def __init__(self, input_nodes, hidden_nodes_1, hidden_nodes_2, hidden_nodes_3, output_nodes, learning_rate=0.1):
        """
        The network consists of three layers: input layer, hidden layer and output layer.
        Here defined these layers
        :param input_nodes: dimension of input
        :param hidden_nodes_1/2/3: dimension of hidden nodes
        :param output_nodes: dimension of output
        :param learning_rate: the learning rate of neural network
        """
        # 初始化纬度和学习率
        self.input_nodes = input_nodes
        self.hn1 = hidden_nodes_1
        self.hn2 = hidden_nodes_2
        self.hn3 = hidden_nodes_3
        self.output_nodes = output_nodes
        self.lr = learning_rate
        # 输入
        self.inputs_hn1 = None
        # 输出
        self.hn1_hn2 = None
        self.hn2_hn3 = None
        self.hn3_outputs = None
        self.outputs = None
        # 初始化权重 (0.0分布均值, 分布的标准偏差, shape)
        self.w_i_h1 = np.random.normal(0.0, pow(self.input_nodes, -0.5), (self.hn1, self.input_nodes))
        self.w_h1_h2 = np.random.normal(0.0, pow(self.hn1, -0.5), (self.hn2, self.hn1))
        self.w_h2_h3 = np.random.normal(0.0, pow(self.hn2, -0.5), (self.hn3, self.hn2))
        self.w_h3_o = np.random.normal(0.0, pow(self.hn3, -0.5), (self.output_nodes, self.hn3))
        # 初始化激活函数
        self.activation_function = lambda x: 1. / (1 + np.exp(-x))

    def forward(self, input_feature):
        """
        Forward the neural network
        :param input_feature: single input image, flattened [784, ]
        """
        # 前向传播计算输出
        self.inputs_hn1 = np.array(input_feature, ndmin=2).T
        self.hn1_hn2 = self.activation_function(np.dot(self.w_i_h1, self.inputs_hn1))
        self.hn2_hn3 = self.activation_function(np.dot(self.w_h1_h2, self.hn1_hn2))
        self.hn3_outputs = self.activation_function(np.dot(self.w_h2_h3, self.hn2_hn3))
        self.outputs = self.activation_function(np.dot(self.w_h3_o, self.hn3_outputs))
        return

    def backpropagation(self, targets_list):
        """
        Propagate backwards
        :param targets_list: output onehot code of a single image, [10, ]
        """
        # 反向传播误差 更新权重
        # 记sigmoid激活函数为S，S的导数为S*(1-S)，根据链式法则，负梯度方向更新
        targets = np.array(targets_list, ndmin=2).T
        output_loss = targets - self.outputs
        hidden3_loss = np.dot(self.w_h3_o.T, output_loss)
        hidden2_loss = np.dot(self.w_h2_h3.T, hidden3_loss)
        hidden1_loss = np.dot(self.w_h1_h2.T, hidden2_loss)

        self.w_h3_o += self.lr * np.dot((output_loss * self.outputs * (1.0 - self.outputs)),
                                        np.transpose(self.hn3_outputs))
        self.w_h2_h3 += self.lr * np.dot((hidden3_loss * self.hn3_outputs * (1.0 - self.hn3_outputs)),
                                         np.transpose(self.hn2_hn3))
        self.w_h1_h2 += self.lr * np.dot((hidden2_loss * self.hn2_hn3 * (1.0 - self.hn2_hn3)),
                                         np.transpose(self.hn1_hn2))
        self.w_i_h1 += self.lr * np.dot((hidden1_loss * self.hn1_hn2 * (1.0 - self.hn1_hn2)),
                                        np.transpose(self.inputs_hn1))

        return np.sum(output_loss ** 2)
