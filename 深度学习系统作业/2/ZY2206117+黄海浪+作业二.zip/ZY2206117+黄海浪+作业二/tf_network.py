import tensorflow as tf


# from tensorflow.contrib.layers import flatten


class LeNet:

    def __init__(self):
        """
        Define some basic parameters here
        """
        self.conv1_weights = LeNet.init_weight([5, 5, 1, 28])
        self.conv1_biases = LeNet.init_bias([28])
        self.conv2_weights = LeNet.init_weight([5, 5, 28, 56])
        self.conv2_biases = LeNet.init_bias([56])
        self.fc1_weights = LeNet.init_weight([7 * 7 * 56, 1024])
        self.fc1_biases = LeNet.init_bias([1024])
        self.fc2_weights = LeNet.init_weight([1024, 10])
        self.fc2_biases = LeNet.init_bias([10])

    def net(self, feats):
        """
        Define network.
        You can use init_weight() and init_bias() function to init weight matrix,
        for example:
            conv1_W = self.init_weight((3, 3, 1, 6))
            conv1_b = self.init_bias(6)
        :param feats: input features
        :return: logits
        """
        # layer 1
        # TODO: construct the conv1
        # 移动步长为1, 使用全0填充
        conv1 = tf.nn.conv2d(feats, self.conv1_weights, strides=[1, 1, 1, 1], padding='SAME')
        # 激活函数Relu去线性化
        relu1 = tf.nn.relu(tf.nn.bias_add(conv1, self.conv1_biases))
        # layer 2
        # TODO: construct the pool1
        pool1 = tf.nn.max_pool(relu1, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
        # layer 3
        # TODO: construct the conv2
        conv2 = tf.nn.conv2d(pool1, self.conv2_weights, strides=[1, 1, 1, 1], padding='SAME')

        relu2 = tf.nn.relu(tf.nn.bias_add(conv2, self.conv2_biases))
        # layer 4
        # TODO: construct the pool2
        pool2 = tf.nn.max_pool(relu2, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
        # layer 5
        # TODO: construct the fc1
        pool2_vector = tf.reshape(pool2, [-1, 7 * 7 * 56])

        fc1 = tf.nn.relu(tf.matmul(pool2_vector, self.fc1_weights) + self.fc1_biases)
        # layer 2
        # TODO: construct the fc2
        fc2 = tf.matmul(fc1, self.fc2_weights) + self.fc2_biases
        y_conv = tf.nn.softmax(fc2)
        return y_conv

    def forward(self, feats):
        """
        Forward the network
        """
        return self.net(feats)

    @staticmethod
    def init_weight(shape):
        """
        Init weight parameter.
        """
        w = tf.truncated_normal(shape=shape, mean=0, stddev=0.1)
        return tf.Variable(w)

    @staticmethod
    def init_bias(shape):
        """
        Init bias parameter.
        """
        b = tf.zeros(shape)
        return tf.Variable(b)
